﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coffe_shop.menu.UI
{
    internal class MENU_UI
    {
        public static void header()
        {
            Console.WriteLine("\t\t************************************");
            Console.WriteLine("\t\t <<<<<  TEESHAS COFFE SHOP  >>>>>   ");
            Console.WriteLine("\t\t************************************");
        } 
        public static int menu()
        {
            header();
            Console.WriteLine();
            Console.WriteLine("\t------------------------------------------");
            Console.WriteLine("\t ---> SELECT ONE OF THE FOLLOWING OPTIONS:");
            Console.WriteLine("\t------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("\t1.ADD A MENU ITEM ");
            Console.WriteLine("\t2.View the Cheapest Item in the menu");
            Console.WriteLine("\t3.View the Drink’s Menu");
            Console.WriteLine("\t4.View the Food’s Menu");
            Console.WriteLine("\t5.Add Order");
            Console.WriteLine("\t6.Fulfill the Order");
            Console.WriteLine("\t7.View the Orders’s List");
            Console.WriteLine("\t8.Total Payable Amount");
            Console.WriteLine("\t9.Exit");
            Console.Write("enter option number:");
            int num = int.Parse(Console.ReadLine());
            return num;
        }

    }
}
