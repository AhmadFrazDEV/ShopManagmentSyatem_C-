﻿namespace coffe_shop11.folder.BL
{
    public class list<T>
    {
    }
}