﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using coffe_shop.folder.BL;
using System.Threading.Tasks;

namespace coffe_shop.folder.UI
{
    internal class class_item_ui
    {
        public static class_item_bl add_items()
        {
            class_item_bl data = new class_item_bl();
            Console.Write("enter name of item: ");
            string name = Console.ReadLine();
            data.setname(name);

            Console.Write("enter item type: ");
            string item_type = Console.ReadLine();
            data.setitem_type(item_type);

            Console.Write("enter price of item: ");
            int price = int.Parse(Console.ReadLine());
            data.setprice(price);

           return data;
        } 
        

    }
}
